package com.example.api_app_adso_01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
